from flask import Flask, render_template, request, jsonify
import cv2
import face_recognition
import os
import csv
from datetime import datetime
from playsound import playsound

app = Flask(__name__)

# === CONFIG ===
known_faces_dir = "known_faces"
log_file = "entry_exit_log.csv"
alert_sound_file = "static/alert.wav"
recognized_sound_file = "static/recognized.wav"

# === LOAD KNOWN FACES ===
known_encodings = []
known_names = []

for filename in os.listdir(known_faces_dir):
    if filename.endswith(('.jpg', '.png')):
        path = os.path.join(known_faces_dir, filename)
        image = face_recognition.load_image_file(path)
        encoding = face_recognition.face_encodings(image)
        if encoding:
            known_encodings.append(encoding[0])
            known_names.append(os.path.splitext(filename)[0])

# === CSV SETUP ===
if not os.path.exists(log_file):
    with open(log_file, mode='w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Name", "Entry Time", "Exit Time"])

# === TRACKING ===
entry_times = {}

# === LOGGING FUNCTION ===
def save_log(name, entry, exit_time):
    with open(log_file, mode='a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([name, entry.strftime('%Y-%m-%d %H:%M:%S'),
                         exit_time.strftime('%Y-%m-%d %H:%M:%S')])

# === ROUTES ===
@app.route('/')
def index():
    return render_template('face.html')

@app.route('/log', methods=['POST'])
def log():
    action = request.form['action']

    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()

    if not ret:
        return jsonify({'status': 'error', 'message': 'Camera error'})

    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
    encodings = face_recognition.face_encodings(rgb)
    now = datetime.now()

    if not encodings:
        try:
            playsound(alert_sound_file)
        except Exception as e:
            print(f"Alert sound error: {e}")
        return jsonify({'status': 'alert', 'message': 'No face detected'})

    for face_encoding in encodings:
        matches = face_recognition.compare_faces(known_encodings, face_encoding)
        distances = face_recognition.face_distance(known_encodings, face_encoding)

        if True in matches:
            best_match = distances.argmin()
            name = known_names[best_match]

            # Optional: Play a sound for recognized user
            try:
                playsound(recognized_sound_file)
            except Exception as e:
                print(f"Recognized sound error: {e}")

            if action == 'entry':
                if name not in entry_times:
                    entry_times[name] = now
                    return jsonify({'status': 'success', 'message': f'{name} entry logged at {now.strftime("%H:%M:%S")}'})
                else:
                    return jsonify({'status': 'info', 'message': f'{name} already logged in at {entry_times[name].strftime("%H:%M:%S")}'})

            elif action == 'exit':
                if name in entry_times:
                    save_log(name, entry_times[name], now)
                    del entry_times[name]
                    return jsonify({'status': 'success', 'message': f'{name} exit logged at {now.strftime("%H:%M:%S")}'})
                else:
                    return jsonify({'status': 'info', 'message': f'No entry record found for {name}'})
        else:
            try:
                playsound(alert_sound_file)
            except Exception as e:
                print(f"Alert sound error: {e}")
            return jsonify({'status': 'alert', 'message': 'Unknown face detected'})

    return jsonify({'status': 'error', 'message': 'No recognized face'})

if __name__ == '__main__':
    app.run(debug=True)
