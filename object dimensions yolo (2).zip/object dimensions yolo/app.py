from flask import Flask, render_template, request, redirect, url_for
import os
import numpy as np
import cv2
from yolo_utils import detect_objects, calculate_dimensions

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return redirect(request.url)
    
    file = request.files['image']
    
    if file and allowed_file(file.filename):
        # Save the uploaded image
        filename = 'uploaded_image.jpg'
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Load and process the image
        image = cv2.imread(filepath)
        orig_image = image.copy()

        # Detect objects with YOLOv8
        boxes = detect_objects(image)
        
        if len(boxes) > 0:
            # Assume the first detected object is the one to measure
            box = boxes[0]
            
            # Calculate dimensions in cm using A4 paper reference
            width_cm, height_cm, surface_area_cm2 = calculate_dimensions(orig_image, box)

            # Save the output image with bounding boxes
            for box in boxes:
                x_min, y_min, x_max, y_max = box
                cv2.rectangle(image, (int(x_min), int(y_min)), (int(x_max), int(y_max)), (0, 255, 0), 2)
            
            output_image_filename = 'output_image.jpg'
            output_image_path = os.path.join(app.config['UPLOAD_FOLDER'], output_image_filename)
            cv2.imwrite(output_image_path, image)

            # Correct the file path for serving (to static/uploads/output_image.jpg)
            output_image_url = url_for('static', filename='uploads/' + output_image_filename)

            # Return the results to the frontend
            result = {
                'width_cm': width_cm,
                'height_cm': height_cm,
                'area_cm2': surface_area_cm2,
                'output_image_url': output_image_url  # Pass the image URL to HTML
            }

            return render_template('index.html', result=result)
    
    return redirect(request.url)

if __name__ == '__main__':
    app.run(debug=True)
