import numpy as np
import cv2
from ultralytics import YOLO

# Load YOLOv8 model
yolo_model = YOLO("yolov8n.pt")  # You can replace with your custom model if needed

def detect_objects(image):
    results = yolo_model(image)
    return results[0].boxes.xyxy.cpu().numpy()  # xyxy format: [x_min, y_min, x_max, y_max]

def calculate_dimensions(image, box, reference_width_cm=21):
    """
    Calculates object dimensions (width, height, area) in centimeters based on the A4 paper reference.
    """
    # Extract coordinates of the bounding box
    x_min, y_min, x_max, y_max = box

    # Calculate width and height in pixels
    width_pixels = x_max - x_min
    height_pixels = y_max - y_min

    # Use A4 paper reference to convert pixels to real-world dimensions (cm)
    reference_width_pixels = 210  # Width of A4 paper in pixels (adjust according to your image)
    pixel_per_cm = width_pixels / reference_width_cm  # Pixel per cm scale

    # Calculate dimensions in cm
    width_cm = width_pixels / pixel_per_cm
    height_cm = height_pixels / pixel_per_cm
    surface_area_cm2 = width_cm * height_cm

    return width_cm, height_cm, surface_area_cm2
