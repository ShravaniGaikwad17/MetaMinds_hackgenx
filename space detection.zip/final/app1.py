from flask import Flask, request, render_template, redirect, url_for
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Rectangle
from ultralytics import YOLO

# ==== USER CONFIG ==== 
FREE_CLASS_NAME = "empty"
CONFIDENCE_THRESHOLD = 0.4
REFERENCE_WIDTH_CM = 21
SHELF_DEPTH_CM = 30
CM2_TO_FT2 = 0.00107639

# ==== FLASK CONFIG ==== 
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# ==== HELPER FUNCTIONS ==== 
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def load_image(image_path):
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    img = cv2.imread(image_path)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img, img_rgb

def run_yolo_detection(image_path):
    model = YOLO("best.pt")
    results = model(image_path, conf=CONFIDENCE_THRESHOLD)
    return results[0]

def calculate_product_dimensions(product_image_path):
    product_img = cv2.imread(product_image_path)
    gray = cv2.cvtColor(product_img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not contours:
        raise ValueError("No contours found in product image.")

    largest_contour = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(largest_contour)
    pixels_per_cm = w / REFERENCE_WIDTH_CM
    width_cm = w / pixels_per_cm
    height_cm = h / pixels_per_cm
    return width_cm, height_cm, pixels_per_cm

def detect_empty_spaces(results):
    boxes = results.boxes.xyxy.cpu().numpy()
    class_ids = results.boxes.cls.cpu().numpy().astype(int)
    names = results.names
    free_class_id = next((k for k, v in names.items() if v.lower() == FREE_CLASS_NAME), None)
    free_boxes_px = []
    total_free_pixel_area = 0
    for i, box in enumerate(boxes):
        if class_ids[i] == free_class_id:
            x1, y1, x2, y2 = map(int, box[:4])
            w_px, h_px = x2 - x1, y2 - y1
            total_free_pixel_area += w_px * h_px
            free_boxes_px.append((x1, y1, x2, y2))
    return free_boxes_px, total_free_pixel_area

# ==== ROUTES ==== 
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    if 'shelf_image' not in request.files or 'product_image' not in request.files:
        return redirect(request.url)

    shelf_file = request.files['shelf_image']
    product_file = request.files['product_image']

    if shelf_file and allowed_file(shelf_file.filename) and product_file and allowed_file(product_file.filename):
        shelf_filename = os.path.join(app.config['UPLOAD_FOLDER'], shelf_file.filename)
        product_filename = os.path.join(app.config['UPLOAD_FOLDER'], product_file.filename)
        shelf_file.save(shelf_filename)
        product_file.save(product_filename)

        # Process images
        img, img_rgb = load_image(shelf_filename)
        results = run_yolo_detection(shelf_filename)
        product_width_cm, product_height_cm, pixels_per_cm = calculate_product_dimensions(product_filename)
        free_boxes_px, total_free_pixel_area = detect_empty_spaces(results)

        # Generate 2D plot for empty spaces
        plot_2d_image(img_rgb, free_boxes_px)

        # Show results and visualizations
        return render_template('results.html', free_area_cm2=total_free_pixel_area, product_width=product_width_cm, product_height=product_height_cm)

    return redirect(url_for('index'))

# ==== IMAGE PLOTTING FUNCTIONS ==== 
def plot_2d_image(img_rgb, free_boxes_px):
    plt.figure(figsize=(8, 8))
    plt.imshow(img_rgb)
    ax = plt.gca()
    for (x1, y1, x2, y2) in free_boxes_px:
        rect = Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='cyan', facecolor='none')
        ax.add_patch(rect)
    plt.title("Detected Empty Spaces (2D View)")
    plt.axis('off')
    plt.savefig('static/2d_image.png')
    plt.close()

# ==== RUNNING THE APP ==== 
if __name__ == "__main__":
    app.run(debug=True)
